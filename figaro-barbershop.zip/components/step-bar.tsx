import React from "react";
import { View, Text, StyleSheet } from "react-native";

const STEPS = [
  { num: "01", label: "SERVIZIO" },
  { num: "02", label: "DATA" },
  { num: "03", label: "ORARIO" },
  { num: "04", label: "CONFERMA" },
];

interface StepBarProps {
  currentStep: 1 | 2 | 3 | 4;
}

export function StepBar({ currentStep }: StepBarProps) {
  return (
    <View style={styles.container}>
      {STEPS.map((step, index) => {
        const stepNum = index + 1;
        const isActive = stepNum === currentStep;
        const isCompleted = stepNum < currentStep;
        return (
          <React.Fragment key={step.num}>
            <View style={styles.stepItem}>
              <Text
                style={[
                  styles.stepNum,
                  isActive && styles.activeNum,
                  isCompleted && styles.completedNum,
                ]}
              >
                {step.num}
              </Text>
              <Text
                style={[
                  styles.stepLabel,
                  isActive && styles.activeLabel,
                  isCompleted && styles.completedLabel,
                ]}
              >
                {step.label}
              </Text>
            </View>
            {index < STEPS.length - 1 && (
              <View style={[styles.divider, isCompleted && styles.dividerCompleted]} />
            )}
          </React.Fragment>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: "#0A0A0A",
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  stepItem: {
    alignItems: "center",
    gap: 2,
  },
  divider: {
    flex: 1,
    height: 1,
    backgroundColor: "#2A2A2A",
    marginHorizontal: 4,
    marginBottom: 10,
  },
  dividerCompleted: {
    backgroundColor: "#C9A84C",
  },
  stepNum: {
    fontSize: 11,
    fontWeight: "700",
    color: "#4A4A4A",
    letterSpacing: 1,
  },
  activeNum: {
    color: "#C9A84C",
  },
  completedNum: {
    color: "#C9A84C",
    opacity: 0.6,
  },
  stepLabel: {
    fontSize: 8,
    fontWeight: "600",
    color: "#4A4A4A",
    letterSpacing: 1,
  },
  activeLabel: {
    color: "#C9A84C",
  },
  completedLabel: {
    color: "#C9A84C",
    opacity: 0.6,
  },
});
