import { describe, it, expect } from "vitest";

// ─── Helpers (duplicated from routers.ts for unit testing) ───────────────────

function generateTimeSlots(start: string, end: string, durationMinutes: number): string[] {
  const slots: string[] = [];
  const [startH, startM] = start.split(":").map(Number);
  const [endH, endM] = end.split(":").map(Number);
  let current = startH * 60 + startM;
  const endTotal = endH * 60 + endM;
  while (current + durationMinutes <= endTotal) {
    const h = Math.floor(current / 60).toString().padStart(2, "0");
    const m = (current % 60).toString().padStart(2, "0");
    slots.push(`${h}:${m}`);
    current += durationMinutes;
  }
  return slots;
}

type DayKey = "sunday" | "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday";

function getDayKey(dateStr: string): DayKey {
  const days: DayKey[] = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  const d = new Date(dateStr + "T12:00:00");
  return days[d.getDay()];
}

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("generateTimeSlots", () => {
  it("genera slot da 08:30 a 13:00 con durata 30 min", () => {
    const slots = generateTimeSlots("08:30", "13:00", 30);
    expect(slots).toContain("08:30");
    expect(slots).toContain("09:00");
    expect(slots).toContain("12:30");
    expect(slots).not.toContain("13:00"); // 13:00 + 30 = 13:30 > 13:00
    expect(slots.length).toBe(9);
  });

  it("genera slot da 15:30 a 20:00 con durata 30 min", () => {
    const slots = generateTimeSlots("15:30", "20:00", 30);
    expect(slots[0]).toBe("15:30");
    expect(slots[slots.length - 1]).toBe("19:30");
    expect(slots.length).toBe(9);
  });

  it("genera slot con durata 20 min", () => {
    const slots = generateTimeSlots("09:00", "10:00", 20);
    expect(slots).toEqual(["09:00", "09:20", "09:40"]);
  });

  it("restituisce array vuoto se la durata supera l'intervallo", () => {
    const slots = generateTimeSlots("09:00", "09:20", 30);
    expect(slots).toEqual([]);
  });
});

describe("getDayKey", () => {
  it("identifica correttamente il giorno della settimana", () => {
    // 2026-05-01 è un venerdì
    expect(getDayKey("2026-05-01")).toBe("friday");
    // 2026-05-02 è un sabato
    expect(getDayKey("2026-05-02")).toBe("saturday");
    // 2026-05-03 è una domenica
    expect(getDayKey("2026-05-03")).toBe("sunday");
    // 2026-05-04 è un lunedì
    expect(getDayKey("2026-05-04")).toBe("monday");
  });
});

describe("Logica slot disponibili", () => {
  it("filtra correttamente gli slot già prenotati", () => {
    const allSlots = generateTimeSlots("09:00", "12:00", 30);
    const bookedTimes = new Set(["09:30", "10:30"]);
    const available = allSlots.filter((s) => !bookedTimes.has(s));
    expect(available).not.toContain("09:30");
    expect(available).not.toContain("10:30");
    expect(available).toContain("09:00");
    expect(available).toContain("10:00");
    expect(available).toContain("11:30");
  });
});

describe("Validazione formato dati", () => {
  it("verifica formato data YYYY-MM-DD", () => {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    expect(dateRegex.test("2026-05-01")).toBe(true);
    expect(dateRegex.test("2026-5-1")).toBe(false);
    expect(dateRegex.test("01-05-2026")).toBe(false);
  });

  it("verifica formato orario HH:MM", () => {
    const timeRegex = /^\d{2}:\d{2}$/;
    expect(timeRegex.test("08:30")).toBe(true);
    expect(timeRegex.test("8:30")).toBe(false);
    expect(timeRegex.test("08:3")).toBe(false);
  });

  it("verifica formato telefono", () => {
    const isValidPhone = (phone: string) => phone.trim().length >= 6;
    expect(isValidPhone("3391234567")).toBe(true);
    expect(isValidPhone("123")).toBe(false);
    expect(isValidPhone("")).toBe(false);
  });
});

describe("Credenziali admin", () => {
  it("accetta le credenziali corrette", () => {
    const checkAdmin = (username: string, password: string) =>
      username === "admin" && password === "figaro2021";
    expect(checkAdmin("admin", "figaro2021")).toBe(true);
    expect(checkAdmin("admin", "wrongpassword")).toBe(false);
    expect(checkAdmin("user", "figaro2021")).toBe(false);
  });
});
