import { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const DAYS_IT = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
const MONTHS_IT = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];

function formatDate(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00");
  return `${DAYS_IT[d.getDay()]} ${d.getDate()} ${MONTHS_IT[d.getMonth()]}`;
}

type Booking = {
  id: number;
  serviceName: string;
  servicePrice: number;
  bookingDate: string;
  bookingTime: string;
  status: "confirmed" | "cancelled";
};

export default function MyBookingsScreen() {
  const router = useRouter();
  const { savedPhone } = useBooking();
  const [cancelTarget, setCancelTarget] = useState<number | null>(null);

  const { data: bookings, isLoading, refetch } = trpc.bookings.getByPhone.useQuery(
    { phone: savedPhone ?? "" },
    { enabled: !!savedPhone }
  );

  const cancelMutation = trpc.bookings.cancel.useMutation({
    onSuccess: () => {
      setCancelTarget(null);
      refetch();
    },
  });

  const handleCancelConfirm = () => {
    if (cancelTarget !== null) {
      cancelMutation.mutate({ id: cancelTarget });
    }
  };

  const confirmed = (bookings ?? []).filter((b) => b.status === "confirmed");
  const cancelled = (bookings ?? []).filter((b) => b.status === "cancelled");

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← INDIETRO</Text>
        </TouchableOpacity>
        <Text style={styles.title}>LE MIE PRENOTAZIONI</Text>
        {savedPhone && <Text style={styles.phoneLabel}>{savedPhone}</Text>}
      </View>

      {!savedPhone ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>Nessun telefono salvato.</Text>
          <TouchableOpacity style={styles.bookBtn} onPress={() => router.push("/register" as never)}>
            <Text style={styles.bookBtnText}>PRENOTA ORA</Text>
          </TouchableOpacity>
        </View>
      ) : isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color="#C9A84C" size="large" />
        </View>
      ) : confirmed.length === 0 && cancelled.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>Nessuna prenotazione trovata.</Text>
          <TouchableOpacity style={styles.bookBtn} onPress={() => router.push("/register" as never)}>
            <Text style={styles.bookBtnText}>PRENOTA ORA</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={[...confirmed, ...cancelled]}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            const isConfirmed = item.status === "confirmed";
            return (
              <View style={[styles.bookingCard, !isConfirmed && styles.bookingCardCancelled]}>
                <View style={styles.bookingInfo}>
                  <View style={styles.bookingTop}>
                    <Text style={styles.bookingService}>{item.serviceName}</Text>
                    <View style={[styles.statusBadge, !isConfirmed && styles.statusBadgeCancelled]}>
                      <Text style={[styles.statusText, !isConfirmed && styles.statusTextCancelled]}>
                        {isConfirmed ? "CONFERMATA" : "CANCELLATA"}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.bookingDateTime}>
                    {formatDate(item.bookingDate)} · {item.bookingTime}
                  </Text>
                  <Text style={styles.bookingPrice}>€{(item.servicePrice / 100).toFixed(0)}</Text>
                </View>
                {isConfirmed && (
                  <TouchableOpacity
                    style={styles.cancelBtn}
                    onPress={() => setCancelTarget(item.id)}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.cancelBtnText}>CANCELLA</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          }}
        />
      )}

      {/* New Booking Button */}
      <View style={styles.bottomBar}>
        <TouchableOpacity
          style={styles.newBookingBtn}
          onPress={() => router.push("/register" as never)}
          activeOpacity={0.85}
        >
          <Text style={styles.newBookingBtnText}>NUOVA PRENOTAZIONE</Text>
        </TouchableOpacity>
      </View>

      {/* Cancel Confirmation Modal */}
      <Modal
        visible={cancelTarget !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setCancelTarget(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>CANCELLA PRENOTAZIONE</Text>
            <Text style={styles.modalText}>
              Sei sicuro di voler cancellare questa prenotazione?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.modalCancelBtn}
                onPress={() => setCancelTarget(null)}
                activeOpacity={0.8}
              >
                <Text style={styles.modalCancelText}>ANNULLA</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalConfirmBtn}
                onPress={handleCancelConfirm}
                disabled={cancelMutation.isPending}
                activeOpacity={0.85}
              >
                {cancelMutation.isPending ? (
                  <ActivityIndicator color="#0A0A0A" size="small" />
                ) : (
                  <Text style={styles.modalConfirmText}>CONFERMA</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: { fontSize: 20, fontWeight: "700", color: "#FFFFFF", letterSpacing: 3, marginBottom: 4 },
  phoneLabel: { fontSize: 12, color: "#9A9A9A" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
  empty: { flex: 1, justifyContent: "center", alignItems: "center", gap: 20, padding: 32 },
  emptyText: { fontSize: 14, color: "#9A9A9A", textAlign: "center" },
  bookBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 2,
  },
  bookBtnText: { color: "#0A0A0A", fontSize: 13, fontWeight: "800", letterSpacing: 3 },

  listContent: { paddingHorizontal: 24, paddingTop: 16, paddingBottom: 100, gap: 10 },
  bookingCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  bookingCardCancelled: { opacity: 0.5 },
  bookingInfo: { flex: 1, gap: 6 },
  bookingTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  bookingService: { fontSize: 15, fontWeight: "600", color: "#FFFFFF" },
  statusBadge: {
    backgroundColor: "#0A2A0A",
    borderWidth: 1,
    borderColor: "#22C55E",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 2,
  },
  statusBadgeCancelled: {
    backgroundColor: "#2A0A0A",
    borderColor: "#EF4444",
  },
  statusText: { fontSize: 9, color: "#22C55E", fontWeight: "700", letterSpacing: 1 },
  statusTextCancelled: { color: "#EF4444" },
  bookingDateTime: { fontSize: 13, color: "#9A9A9A" },
  bookingPrice: { fontSize: 14, color: "#C9A84C", fontWeight: "700" },

  cancelBtn: {
    marginLeft: 12,
    borderWidth: 1,
    borderColor: "#EF4444",
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 2,
  },
  cancelBtnText: { fontSize: 9, color: "#EF4444", fontWeight: "700", letterSpacing: 1 },

  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: "#0A0A0A",
    borderTopWidth: 1,
    borderTopColor: "#2A2A2A",
  },
  newBookingBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 14,
    borderRadius: 2,
    alignItems: "center",
  },
  newBookingBtnText: { color: "#0A0A0A", fontSize: 13, fontWeight: "800", letterSpacing: 3 },

  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.8)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  modalCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 24,
    width: "100%",
    gap: 16,
  },
  modalTitle: { fontSize: 14, fontWeight: "800", color: "#FFFFFF", letterSpacing: 3, textAlign: "center" },
  modalText: { fontSize: 13, color: "#9A9A9A", textAlign: "center", lineHeight: 20 },
  modalButtons: { flexDirection: "row", gap: 10 },
  modalCancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#2A2A2A",
    paddingVertical: 12,
    borderRadius: 2,
    alignItems: "center",
  },
  modalCancelText: { color: "#9A9A9A", fontSize: 12, fontWeight: "600", letterSpacing: 1 },
  modalConfirmBtn: {
    flex: 1,
    backgroundColor: "#EF4444",
    paddingVertical: 12,
    borderRadius: 2,
    alignItems: "center",
  },
  modalConfirmText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700", letterSpacing: 1 },
});
