import { useEffect, useState } from "react";
import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { StepBar } from "@/components/step-bar";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const DAYS_IT = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
const MONTHS_IT = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];

function formatDateFull(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00");
  return `${DAYS_IT[d.getDay()]} ${d.getDate()} ${MONTHS_IT[d.getMonth()]}`;
}

export default function ConfirmScreen() {
  const router = useRouter();
  const { booking, resetBooking } = useBooking();
  const [error, setError] = useState<string | null>(null);

  const createBooking = trpc.bookings.create.useMutation({
    onSuccess: () => {
      resetBooking();
      router.push("/success" as never);
    },
    onError: (err) => {
      setError(err.message || "Errore durante la prenotazione");
    },
  });

  useEffect(() => {
    if (!booking.customer || !booking.service || !booking.date || !booking.time) {
      router.replace("/" as never);
    }
  }, [booking.customer, booking.service, booking.date, booking.time, router]);

  const handleConfirm = () => {
    setError(null);
    setTimeout(() => {
      createBooking.mutate({
        firstName: booking.customer!.firstName,
        lastName: booking.customer!.lastName,
        phone: booking.customer!.phone,
        serviceId: booking.service!.id,
        serviceName: booking.service!.name,
        servicePrice: booking.service!.price,
        serviceDuration: booking.service!.duration,
        bookingDate: booking.date!,
        bookingTime: booking.time!,
      });
    }, 0);
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StepBar currentStep={4} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← MODIFICA</Text>
          </TouchableOpacity>
          <Text style={styles.title}>RIEPILOGO</Text>
          <Text style={styles.subtitle}>Verifica i dettagli prima di confermare</Text>
        </View>

        {/* Receipt Card */}
        <View style={styles.receiptCard}>
          <View style={styles.receiptHeader}>
            <Text style={styles.receiptTitle}>FIGARO BARBERSHOP</Text>
            <Text style={styles.receiptSubtitle}>PRENOTAZIONE</Text>
          </View>

          <View style={styles.receiptDivider} />

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>CLIENTE</Text>
            <Text style={styles.receiptValue}>
              {booking.customer?.firstName} {booking.customer?.lastName}
            </Text>
          </View>

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>TELEFONO</Text>
            <Text style={styles.receiptValue}>{booking.customer?.phone}</Text>
          </View>

          <View style={styles.receiptDivider} />

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>SERVIZIO</Text>
            <Text style={styles.receiptValue}>{booking.service?.name}</Text>
          </View>

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>DURATA</Text>
            <Text style={styles.receiptValue}>{booking.service?.duration} minuti</Text>
          </View>

          <View style={styles.receiptDivider} />

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>DATA</Text>
            <Text style={styles.receiptValue}>{booking.date ? formatDateFull(booking.date) : ""}</Text>
          </View>

          <View style={styles.receiptRow}>
            <Text style={styles.receiptLabel}>ORARIO</Text>
            <Text style={styles.receiptValue}>{booking.time}</Text>
          </View>

          <View style={styles.receiptDivider} />

          <View style={styles.receiptRow}>
            <Text style={styles.receiptTotalLabel}>TOTALE</Text>
            <Text style={styles.receiptTotal}>€{booking.service ? (booking.service.price / 100).toFixed(0) : "0"}</Text>
          </View>
        </View>

        {error && (
          <View style={styles.errorBox}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        )}

        {/* Confirm Button */}
        <TouchableOpacity
          style={[styles.confirmBtn, createBooking.isPending && styles.confirmBtnDisabled]}
          onPress={handleConfirm}
          disabled={createBooking.isPending}
          activeOpacity={0.85}
        >
          {createBooking.isPending ? (
            <ActivityIndicator color="#0A0A0A" />
          ) : (
            <Text style={styles.confirmBtnText}>CONFERMA PRENOTAZIONE</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.cancelBtn}
          onPress={() => router.replace("/" as never)}
          activeOpacity={0.7}
        >
          <Text style={styles.cancelBtnText}>ANNULLA</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: "#0A0A0A" },
  scrollContent: { paddingBottom: 40 },

  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: { fontSize: 22, fontWeight: "700", color: "#FFFFFF", letterSpacing: 3, marginBottom: 6 },
  subtitle: { fontSize: 13, color: "#9A9A9A" },

  receiptCard: {
    marginHorizontal: 24,
    marginTop: 24,
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    overflow: "hidden",
  },
  receiptHeader: {
    backgroundColor: "#C9A84C",
    paddingVertical: 14,
    paddingHorizontal: 20,
    alignItems: "center",
    gap: 2,
  },
  receiptTitle: { fontSize: 14, fontWeight: "800", color: "#0A0A0A", letterSpacing: 3 },
  receiptSubtitle: { fontSize: 10, fontWeight: "600", color: "#0A0A0A", letterSpacing: 4, opacity: 0.7 },

  receiptDivider: {
    height: 1,
    backgroundColor: "#2A2A2A",
    marginHorizontal: 20,
  },
  receiptRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  receiptLabel: { fontSize: 10, color: "#9A9A9A", letterSpacing: 2, fontWeight: "600" },
  receiptValue: { fontSize: 13, color: "#FFFFFF", fontWeight: "500", textAlign: "right", flex: 1, marginLeft: 16 },
  receiptTotalLabel: { fontSize: 12, color: "#C9A84C", letterSpacing: 2, fontWeight: "700" },
  receiptTotal: { fontSize: 22, color: "#C9A84C", fontWeight: "800" },

  errorBox: {
    marginHorizontal: 24,
    marginTop: 16,
    backgroundColor: "#1A0A0A",
    borderWidth: 1,
    borderColor: "#EF4444",
    borderRadius: 2,
    padding: 12,
  },
  errorText: { color: "#EF4444", fontSize: 13, textAlign: "center" },

  confirmBtn: {
    marginHorizontal: 24,
    marginTop: 24,
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
  },
  confirmBtnDisabled: { opacity: 0.6 },
  confirmBtnText: { color: "#0A0A0A", fontSize: 14, fontWeight: "800", letterSpacing: 3 },

  cancelBtn: {
    marginHorizontal: 24,
    marginTop: 12,
    paddingVertical: 14,
    alignItems: "center",
  },
  cancelBtnText: { color: "#4A4A4A", fontSize: 11, letterSpacing: 2, fontWeight: "600" },
});
