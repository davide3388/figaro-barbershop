import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663619095330/F5CEDPAP64kSyYnUY5joFT/figaro-logo-dHGfp8dqetyhv7udTJTNRF.png";

export default function HomeScreen() {
  const router = useRouter();

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Hero Section */}
        <View style={styles.hero}>
          <View style={styles.heroOverlay} />
          <View style={styles.heroContent}>
            <Image source={{ uri: LOGO_URL }} style={styles.logo} resizeMode="contain" />
            <View style={styles.dividerLine} />
            <Text style={styles.tagline}>L'ARTE DEL BARBIERE</Text>
            <Text style={styles.subTagline}>Qualità, stile e tradizione dal 2021</Text>
          </View>
        </View>

        {/* Main CTA */}
        <View style={styles.ctaSection}>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => router.push("/register")}
            activeOpacity={0.85}
          >
            <Text style={styles.primaryButtonText}>PRENOTA ORA</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => router.push("/my-bookings")}
            activeOpacity={0.85}
          >
            <Text style={styles.secondaryButtonText}>LE MIE PRENOTAZIONI</Text>
          </TouchableOpacity>
        </View>

        {/* Services Preview */}
        <View style={styles.servicesSection}>
          <Text style={styles.sectionTitle}>I NOSTRI SERVIZI</Text>
          <View style={styles.servicesGrid}>
            {[
              { icon: "✂", name: "Taglio Capelli", price: "€10" },
              { icon: "🪒", name: "Barba", price: "€5" },
              { icon: "✨", name: "Taglio + Shampoo", price: "€15" },
              { icon: "💆", name: "Servizio Completo", price: "€20" },
            ].map((s) => (
              <View key={s.name} style={styles.serviceCard}>
                <Text style={styles.serviceIcon}>{s.icon}</Text>
                <Text style={styles.serviceName}>{s.name}</Text>
                <Text style={styles.servicePrice}>{s.price}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Hours */}
        <View style={styles.hoursSection}>
          <Text style={styles.sectionTitle}>ORARI</Text>
          <View style={styles.hoursCard}>
            <View style={styles.hoursRow}>
              <Text style={styles.hoursDay}>Mar — Ven</Text>
              <Text style={styles.hoursTime}>08:30 – 13:00 / 15:30 – 20:00</Text>
            </View>
            <View style={styles.hoursDivider} />
            <View style={styles.hoursRow}>
              <Text style={styles.hoursDay}>Sabato</Text>
              <Text style={styles.hoursTime}>08:00 – 20:00</Text>
            </View>
            <View style={styles.hoursDivider} />
            <View style={styles.hoursRow}>
              <Text style={styles.hoursDay}>Dom — Lun</Text>
              <Text style={[styles.hoursTime, styles.closed]}>Chiuso</Text>
            </View>
          </View>
        </View>

        {/* Admin Link */}
        <TouchableOpacity
          style={styles.adminLink}
          onPress={() => router.push("/admin/login")}
          activeOpacity={0.7}
        >
          <Text style={styles.adminLinkText}>Area Admin</Text>
        </TouchableOpacity>

        <View style={styles.footer}>
          <Text style={styles.footerText}>FIGARO BARBERSHOP · EST. 2021</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: "#0A0A0A" },
  scrollContent: { paddingBottom: 40 },

  hero: {
    height: 380,
    backgroundColor: "#0A0A0A",
    justifyContent: "center",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  heroOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.6)",
  },
  heroContent: {
    alignItems: "center",
    zIndex: 1,
    paddingHorizontal: 24,
  },
  logo: {
    width: 200,
    height: 200,
  },
  dividerLine: {
    width: 60,
    height: 1,
    backgroundColor: "#C9A84C",
    marginVertical: 12,
  },
  tagline: {
    fontSize: 13,
    fontWeight: "700",
    color: "#C9A84C",
    letterSpacing: 4,
    textAlign: "center",
  },
  subTagline: {
    fontSize: 12,
    color: "#9A9A9A",
    letterSpacing: 1,
    marginTop: 6,
    textAlign: "center",
  },

  ctaSection: {
    paddingHorizontal: 24,
    paddingTop: 32,
    gap: 12,
  },
  primaryButton: {
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
  },
  primaryButtonText: {
    color: "#0A0A0A",
    fontSize: 14,
    fontWeight: "800",
    letterSpacing: 3,
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: "#C9A84C",
    paddingVertical: 14,
    borderRadius: 2,
    alignItems: "center",
  },
  secondaryButtonText: {
    color: "#C9A84C",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 2,
  },

  servicesSection: {
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: "700",
    color: "#C9A84C",
    letterSpacing: 4,
    marginBottom: 16,
  },
  servicesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  serviceCard: {
    width: "47%",
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    padding: 16,
    borderRadius: 2,
    alignItems: "center",
    gap: 6,
  },
  serviceIcon: { fontSize: 24 },
  serviceName: { fontSize: 12, color: "#FFFFFF", fontWeight: "600", textAlign: "center" },
  servicePrice: { fontSize: 14, color: "#C9A84C", fontWeight: "700" },

  hoursSection: {
    paddingHorizontal: 24,
    paddingTop: 32,
  },
  hoursCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 16,
  },
  hoursRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 10,
  },
  hoursDivider: { height: 1, backgroundColor: "#2A2A2A" },
  hoursDay: { fontSize: 12, color: "#9A9A9A", fontWeight: "600" },
  hoursTime: { fontSize: 12, color: "#FFFFFF", fontWeight: "500" },
  closed: { color: "#4A4A4A" },

  adminLink: {
    alignItems: "center",
    paddingTop: 32,
    paddingBottom: 8,
  },
  adminLinkText: {
    fontSize: 11,
    color: "#4A4A4A",
    letterSpacing: 2,
    textDecorationLine: "underline",
  },

  footer: {
    alignItems: "center",
    paddingTop: 16,
  },
  footerText: {
    fontSize: 10,
    color: "#2A2A2A",
    letterSpacing: 3,
  },
});
