import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useEffect } from "react";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { StepBar } from "@/components/step-bar";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const DAYS_IT = ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato"];
const MONTHS_IT = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];

function formatDateFull(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00");
  return `${DAYS_IT[d.getDay()]} ${d.getDate()} ${MONTHS_IT[d.getMonth()]}`;
}

export default function TimeSelectScreen() {
  const router = useRouter();
  const { setTime, booking } = useBooking();

  const { data: slotsData, isLoading } = trpc.bookings.getAvailableSlots.useQuery(
    {
      date: booking.date ?? "",
      duration: booking.service?.duration ?? 30,
    },
    { enabled: !!booking.date && !!booking.service }
  );

  const handleSelect = (time: string) => {
    setTime(time);
    setTimeout(() => {
      router.push("/confirm" as never);
    }, 0);
  };

  useEffect(() => {
    if (!booking.date || !booking.service) {
      router.replace("/date-select" as never);
    }
  }, [booking.date, booking.service, router]);

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StepBar currentStep={3} />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← INDIETRO</Text>
        </TouchableOpacity>
        <Text style={styles.title}>SCEGLI L'ORARIO</Text>
        <Text style={styles.subtitle}>{booking.date ? formatDateFull(booking.date) : ""}</Text>
      </View>

      {/* Recap */}
      {booking.service && (
        <View style={styles.recap}>
          <Text style={styles.recapItem}>{booking.service.name}</Text>
          <Text style={styles.recapDot}>·</Text>
          <Text style={styles.recapItem}>{booking.service.duration} min</Text>
          <Text style={styles.recapDot}>·</Text>
          <Text style={styles.recapItem}>€{(booking.service.price / 100).toFixed(0)}</Text>
        </View>
      )}

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color="#C9A84C" size="large" />
          <Text style={styles.loadingText}>Caricamento orari...</Text>
        </View>
      ) : !slotsData?.isOpen ? (
        <View style={styles.loading}>
          <Text style={styles.closedText}>Il barbershop è chiuso in questa data</Text>
          <TouchableOpacity style={styles.backBtnLarge} onPress={() => router.back()}>
            <Text style={styles.backBtnLargeText}>SCEGLI UN'ALTRA DATA</Text>
          </TouchableOpacity>
        </View>
      ) : (slotsData?.available ?? []).length === 0 ? (
        <View style={styles.loading}>
          <Text style={styles.closedText}>Nessuno slot disponibile per questa data</Text>
          <TouchableOpacity style={styles.backBtnLarge} onPress={() => router.back()}>
            <Text style={styles.backBtnLargeText}>SCEGLI UN'ALTRA DATA</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.slotsLabel}>ORARI DISPONIBILI</Text>
          <View style={styles.slotsGrid}>
            {(slotsData?.available ?? []).map((time) => {
              const isSelected = booking.time === time;
              return (
                <TouchableOpacity
                  key={time}
                  style={[styles.slotCard, isSelected && styles.slotCardSelected]}
                  onPress={() => handleSelect(time)}
                  activeOpacity={0.85}
                >
                  <Text style={[styles.slotTime, isSelected && styles.slotTimeSelected]}>{time}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: { fontSize: 22, fontWeight: "700", color: "#FFFFFF", letterSpacing: 3, marginBottom: 6 },
  subtitle: { fontSize: 14, color: "#9A9A9A" },

  recap: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
    gap: 8,
  },
  recapItem: { fontSize: 12, color: "#C9A84C", fontWeight: "600" },
  recapDot: { fontSize: 12, color: "#4A4A4A" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center", gap: 16, padding: 24 },
  loadingText: { color: "#9A9A9A", fontSize: 13 },
  closedText: { color: "#9A9A9A", fontSize: 14, textAlign: "center" },
  backBtnLarge: {
    borderWidth: 1,
    borderColor: "#C9A84C",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 2,
  },
  backBtnLargeText: { color: "#C9A84C", fontSize: 12, fontWeight: "700", letterSpacing: 2 },

  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 40 },
  slotsLabel: {
    fontSize: 10,
    fontWeight: "700",
    color: "#C9A84C",
    letterSpacing: 4,
    marginBottom: 16,
  },
  slotsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  slotCard: {
    width: "30%",
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    paddingVertical: 14,
    alignItems: "center",
  },
  slotCardSelected: {
    borderColor: "#C9A84C",
    backgroundColor: "#1F1A0F",
  },
  slotTime: { fontSize: 15, fontWeight: "600", color: "#FFFFFF" },
  slotTimeSelected: { color: "#C9A84C" },
});
