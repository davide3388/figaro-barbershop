import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { StepBar } from "@/components/step-bar";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const DAYS_IT = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
const MONTHS_IT = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];

function formatDate(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00");
  return {
    dayName: DAYS_IT[d.getDay()].toUpperCase(),
    dayNum: d.getDate().toString(),
    month: MONTHS_IT[d.getMonth()].toUpperCase(),
  };
}

function getDateRange() {
  const today = new Date();
  const start = today.toISOString().split("T")[0];
  const end = new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  return { start, end };
}

export default function DateSelectScreen() {
  const router = useRouter();
  const { setDate, booking } = useBooking();
  const scrollRef = useRef<ScrollView>(null);

  const { start, end } = getDateRange();
  const { data: openDays, isLoading } = trpc.bookings.getOpenDays.useQuery({ startDate: start, endDate: end });

  const handleSelect = (date: string) => {
    setDate(date);
    setTimeout(() => {
      router.push("/time-select" as never);
    }, 0);
  };

  useEffect(() => {
    if (!booking.service) {
      router.replace("/service-select" as never);
    }
  }, [booking.service, router]);

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StepBar currentStep={2} />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← INDIETRO</Text>
        </TouchableOpacity>
        <Text style={styles.title}>SCEGLI LA DATA</Text>
        <Text style={styles.subtitle}>Prossimi 14 giorni disponibili</Text>
      </View>

      {/* Service recap */}
      {booking.service && (
        <View style={styles.serviceRecap}>
          <Text style={styles.recapLabel}>SERVIZIO SELEZIONATO</Text>
          <Text style={styles.recapValue}>{booking.service.name} — €{(booking.service.price / 100).toFixed(0)}</Text>
        </View>
      )}

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color="#C9A84C" size="large" />
          <Text style={styles.loadingText}>Caricamento disponibilità...</Text>
        </View>
      ) : (
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.datesContainer}
          style={styles.datesScroll}
        >
          {(openDays ?? []).map((date) => {
            const { dayName, dayNum, month } = formatDate(date);
            const isSelected = booking.date === date;
            return (
              <TouchableOpacity
                key={date}
                style={[styles.dateCard, isSelected && styles.dateCardSelected]}
                onPress={() => handleSelect(date)}
                activeOpacity={0.85}
              >
                <Text style={[styles.dateDayName, isSelected && styles.dateTextSelected]}>{dayName}</Text>
                <Text style={[styles.dateDayNum, isSelected && styles.dateNumSelected]}>{dayNum}</Text>
                <Text style={[styles.dateMonth, isSelected && styles.dateTextSelected]}>{month}</Text>
              </TouchableOpacity>
            );
          })}
          {!isLoading && (openDays ?? []).length === 0 && (
            <View style={styles.noSlots}>
              <Text style={styles.noSlotsText}>Nessun giorno disponibile nei prossimi 14 giorni</Text>
            </View>
          )}
        </ScrollView>
      )}

      <View style={styles.hint}>
        <Text style={styles.hintText}>Scorri per vedere più date →</Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: { fontSize: 22, fontWeight: "700", color: "#FFFFFF", letterSpacing: 3, marginBottom: 6 },
  subtitle: { fontSize: 13, color: "#9A9A9A" },

  serviceRecap: {
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  recapLabel: { fontSize: 9, color: "#9A9A9A", letterSpacing: 2, fontWeight: "600" },
  recapValue: { fontSize: 13, color: "#C9A84C", fontWeight: "600" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center", gap: 12 },
  loadingText: { color: "#9A9A9A", fontSize: 13 },

  datesScroll: { flexGrow: 0, paddingVertical: 24 },
  datesContainer: { paddingHorizontal: 24, gap: 10, alignItems: "flex-start" },

  dateCard: {
    width: 72,
    height: 90,
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    alignItems: "center",
    justifyContent: "center",
    gap: 4,
  },
  dateCardSelected: {
    borderColor: "#C9A84C",
    backgroundColor: "#1F1A0F",
  },
  dateDayName: { fontSize: 10, color: "#9A9A9A", fontWeight: "600", letterSpacing: 1 },
  dateDayNum: { fontSize: 26, fontWeight: "700", color: "#FFFFFF" },
  dateMonth: { fontSize: 10, color: "#9A9A9A", fontWeight: "600", letterSpacing: 1 },
  dateTextSelected: { color: "#C9A84C" },
  dateNumSelected: { color: "#FFFFFF" },

  noSlots: { paddingHorizontal: 24, paddingVertical: 40 },
  noSlotsText: { color: "#9A9A9A", fontSize: 14, textAlign: "center" },

  hint: { paddingHorizontal: 24, paddingBottom: 16 },
  hintText: { fontSize: 11, color: "#4A4A4A", textAlign: "center" },
});
