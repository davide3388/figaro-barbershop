import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

export default function SuccessScreen() {
  const router = useRouter();

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}>
      <View style={styles.container}>
        {/* Check Icon */}
        <View style={styles.checkCircle}>
          <Text style={styles.checkIcon}>✓</Text>
        </View>

        {/* Title */}
        <Text style={styles.title}>PRENOTAZIONE{"\n"}CONFERMATA!</Text>

        {/* Divider */}
        <View style={styles.divider} />

        {/* Subtitle */}
        <Text style={styles.subtitle}>
          La tua prenotazione è stata registrata con successo.{"\n"}
          Ti aspettiamo al Figaro Barbershop!
        </Text>

        {/* Buttons */}
        <View style={styles.buttons}>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => router.push("/my-bookings" as never)}
            activeOpacity={0.85}
          >
            <Text style={styles.primaryBtnText}>LE MIE PRENOTAZIONI</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryBtn}
            onPress={() => router.replace("/" as never)}
            activeOpacity={0.85}
          >
            <Text style={styles.secondaryBtnText}>TORNA ALLA HOME</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <Text style={styles.footer}>FIGARO BARBERSHOP · EST. 2021</Text>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 32,
    backgroundColor: "#0A0A0A",
  },
  checkCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: "#C9A84C",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 28,
  },
  checkIcon: { fontSize: 36, color: "#C9A84C" },

  title: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
    letterSpacing: 4,
    textAlign: "center",
    lineHeight: 32,
    marginBottom: 20,
  },
  divider: { width: 60, height: 1, backgroundColor: "#C9A84C", marginBottom: 20 },
  subtitle: {
    fontSize: 13,
    color: "#9A9A9A",
    textAlign: "center",
    lineHeight: 20,
    marginBottom: 40,
  },

  buttons: { width: "100%", gap: 12 },
  primaryBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
  },
  primaryBtnText: { color: "#0A0A0A", fontSize: 13, fontWeight: "800", letterSpacing: 3 },
  secondaryBtn: {
    borderWidth: 1,
    borderColor: "#2A2A2A",
    paddingVertical: 14,
    borderRadius: 2,
    alignItems: "center",
  },
  secondaryBtnText: { color: "#9A9A9A", fontSize: 12, fontWeight: "600", letterSpacing: 2 },

  footer: {
    position: "absolute",
    bottom: 32,
    fontSize: 10,
    color: "#2A2A2A",
    letterSpacing: 3,
  },
});
