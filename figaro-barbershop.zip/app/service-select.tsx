import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { StepBar } from "@/components/step-bar";
import { useBooking, SERVICES, Service } from "@/lib/booking-context";

export default function ServiceSelectScreen() {
  const router = useRouter();
  const { setService, booking } = useBooking();

  const barbiere = SERVICES.filter((s) => s.category === "barbiere");
  const estetica = SERVICES.filter((s) => s.category === "estetica");

  const handleSelect = (service: Service) => {
    setService(service);
    router.push("/date-select" as never);
  };

  const formatPrice = (cents: number) => `€${(cents / 100).toFixed(0)}`;

  const renderServiceCard = (service: Service) => {
    const isSelected = booking.service?.id === service.id;
    return (
      <TouchableOpacity
        key={service.id}
        style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
        onPress={() => handleSelect(service)}
        activeOpacity={0.85}
      >
        <View style={styles.serviceCardLeft}>
          <Text style={styles.serviceName}>{service.name}</Text>
          <Text style={styles.serviceDesc}>{service.description}</Text>
          <Text style={styles.serviceDuration}>{service.duration} min</Text>
        </View>
        <View style={styles.serviceCardRight}>
          <Text style={styles.servicePrice}>{formatPrice(service.price)}</Text>
          {isSelected && <Text style={styles.selectedCheck}>✓</Text>}
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StepBar currentStep={1} />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← INDIETRO</Text>
          </TouchableOpacity>
          <Text style={styles.title}>SCEGLI IL SERVIZIO</Text>
          <Text style={styles.subtitle}>Seleziona il trattamento desiderato</Text>
        </View>

        {/* Sezione Barbiere */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionLine} />
            <Text style={styles.sectionTitle}>BARBIERE</Text>
            <View style={styles.sectionLine} />
          </View>
          {barbiere.map(renderServiceCard)}
        </View>

        {/* Sezione Estetica */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionLine} />
            <Text style={styles.sectionTitle}>ESTETICA</Text>
            <View style={styles.sectionLine} />
          </View>
          {estetica.map(renderServiceCard)}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: "#0A0A0A" },
  scrollContent: { paddingBottom: 40 },

  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: {
    fontSize: 22,
    fontWeight: "700",
    color: "#FFFFFF",
    letterSpacing: 3,
    marginBottom: 6,
  },
  subtitle: { fontSize: 13, color: "#9A9A9A" },

  section: { paddingHorizontal: 24, paddingTop: 28, gap: 10 },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 4,
  },
  sectionLine: { flex: 1, height: 1, backgroundColor: "#2A2A2A" },
  sectionTitle: {
    fontSize: 10,
    fontWeight: "700",
    color: "#C9A84C",
    letterSpacing: 4,
  },

  serviceCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  serviceCardSelected: {
    borderColor: "#C9A84C",
    backgroundColor: "#1F1A0F",
  },
  serviceCardLeft: { flex: 1, gap: 4 },
  serviceCardRight: { alignItems: "flex-end", gap: 6 },
  serviceName: { fontSize: 15, fontWeight: "600", color: "#FFFFFF" },
  serviceDesc: { fontSize: 12, color: "#9A9A9A" },
  serviceDuration: { fontSize: 11, color: "#C9A84C", fontWeight: "600" },
  servicePrice: { fontSize: 18, fontWeight: "700", color: "#C9A84C" },
  selectedCheck: { fontSize: 16, color: "#C9A84C" },
});
