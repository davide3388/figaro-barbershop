import { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const DAYS_IT = ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab"];
const MONTHS_IT = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"];

function formatDate(dateStr: string) {
  const d = new Date(dateStr + "T12:00:00");
  return `${DAYS_IT[d.getDay()]} ${d.getDate()} ${MONTHS_IT[d.getMonth()]}`;
}

function getTodayStr() {
  return new Date().toISOString().split("T")[0];
}

function getWeekRange() {
  const today = new Date();
  const start = today.toISOString().split("T")[0];
  const end = new Date(today.getTime() + 6 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
  return { start, end };
}

type FilterType = "today" | "week" | "all";

type BookingWithCustomer = {
  id: number;
  serviceName: string;
  servicePrice: number;
  bookingDate: string;
  bookingTime: string;
  status: "confirmed" | "cancelled";
  customerFirstName: string | null;
  customerLastName: string | null;
  customerPhone: string | null;
};

export default function AdminDashboardScreen() {
  const router = useRouter();
  const { isAdminLoggedIn, setAdminLoggedIn } = useBooking();
  const [filter, setFilter] = useState<FilterType>("today");
  const [cancelTarget, setCancelTarget] = useState<number | null>(null);

  const today = getTodayStr();
  const { start: weekStart, end: weekEnd } = getWeekRange();

  const allQuery = trpc.bookings.getAll.useQuery(undefined, { enabled: filter === "all" });
  const todayQuery = trpc.bookings.getByDate.useQuery({ date: today }, { enabled: filter === "today" });
  const weekQuery = trpc.bookings.getByDateRange.useQuery(
    { startDate: weekStart, endDate: weekEnd },
    { enabled: filter === "week" }
  );

  const cancelMutation = trpc.bookings.cancel.useMutation({
    onSuccess: () => {
      setCancelTarget(null);
      allQuery.refetch();
      todayQuery.refetch();
      weekQuery.refetch();
    },
  });

  if (!isAdminLoggedIn) {
    router.replace("/admin/login" as never);
    return null;
  }

  const rawData =
    filter === "today" ? (todayQuery.data ?? []) :
    filter === "week" ? (weekQuery.data ?? []) :
    (allQuery.data ?? []);

  const isLoading =
    filter === "today" ? todayQuery.isLoading :
    filter === "week" ? weekQuery.isLoading :
    allQuery.isLoading;

  const bookings = rawData as BookingWithCustomer[];

  const handleLogout = () => {
    setAdminLoggedIn(false);
    router.replace("/" as never);
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.title}>DASHBOARD ADMIN</Text>
          <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
            <Text style={styles.logoutText}>ESCI</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.subtitle}>Gestione prenotazioni</Text>
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterTabs}>
        {(["today", "week", "all"] as FilterType[]).map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterTab, filter === f && styles.filterTabActive]}
            onPress={() => setFilter(f)}
            activeOpacity={0.8}
          >
            <Text style={[styles.filterTabText, filter === f && styles.filterTabTextActive]}>
              {f === "today" ? "OGGI" : f === "week" ? "SETTIMANA" : "TUTTE"}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Count */}
      <View style={styles.countBar}>
        <Text style={styles.countText}>
          {isLoading ? "..." : `${bookings.length} prenotazion${bookings.length === 1 ? "e" : "i"}`}
        </Text>
        <TouchableOpacity onPress={() => router.push("/admin/hours" as never)} style={styles.hoursBtn}>
          <Text style={styles.hoursBtnText}>GESTISCI ORARI →</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color="#C9A84C" size="large" />
        </View>
      ) : bookings.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>Nessuna prenotazione per questo periodo</Text>
        </View>
      ) : (
        <FlatList
          data={bookings}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.bookingCard}>
              <View style={styles.bookingInfo}>
                <View style={styles.bookingTop}>
                  <Text style={styles.customerName}>
                    {item.customerFirstName ?? "—"} {item.customerLastName ?? ""}
                  </Text>
                  <Text style={styles.bookingPrice}>€{(item.servicePrice / 100).toFixed(0)}</Text>
                </View>
                <Text style={styles.bookingService}>{item.serviceName}</Text>
                <Text style={styles.bookingDateTime}>
                  {formatDate(item.bookingDate)} · {item.bookingTime}
                </Text>
                {item.customerPhone && (
                  <Text style={styles.customerPhone}>{item.customerPhone}</Text>
                )}
              </View>
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={() => setCancelTarget(item.id)}
                activeOpacity={0.8}
              >
                <Text style={styles.cancelBtnText}>✕</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}

      {/* Cancel Confirmation Modal */}
      <Modal
        visible={cancelTarget !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setCancelTarget(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>CANCELLA PRENOTAZIONE</Text>
            <Text style={styles.modalText}>
              Sei sicuro di voler cancellare questa prenotazione?
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.modalCancelBtn}
                onPress={() => setCancelTarget(null)}
                activeOpacity={0.8}
              >
                <Text style={styles.modalCancelText}>ANNULLA</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalConfirmBtn}
                onPress={() => cancelTarget !== null && cancelMutation.mutate({ id: cancelTarget })}
                disabled={cancelMutation.isPending}
                activeOpacity={0.85}
              >
                {cancelMutation.isPending ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Text style={styles.modalConfirmText}>CANCELLA</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 4 },
  title: { fontSize: 18, fontWeight: "800", color: "#FFFFFF", letterSpacing: 3 },
  subtitle: { fontSize: 12, color: "#9A9A9A" },
  logoutBtn: {
    borderWidth: 1,
    borderColor: "#2A2A2A",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 2,
  },
  logoutText: { fontSize: 10, color: "#9A9A9A", fontWeight: "600", letterSpacing: 2 },

  filterTabs: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  filterTab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: "center",
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  filterTabActive: { borderBottomColor: "#C9A84C" },
  filterTabText: { fontSize: 11, color: "#4A4A4A", fontWeight: "700", letterSpacing: 2 },
  filterTabTextActive: { color: "#C9A84C" },

  countBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  countText: { fontSize: 12, color: "#9A9A9A" },
  hoursBtn: {},
  hoursBtnText: { fontSize: 10, color: "#C9A84C", fontWeight: "700", letterSpacing: 2 },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
  empty: { flex: 1, justifyContent: "center", alignItems: "center", padding: 32 },
  emptyText: { fontSize: 14, color: "#9A9A9A", textAlign: "center" },

  listContent: { paddingHorizontal: 24, paddingTop: 12, paddingBottom: 40, gap: 10 },
  bookingCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  bookingInfo: { flex: 1, gap: 4 },
  bookingTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  customerName: { fontSize: 14, fontWeight: "700", color: "#FFFFFF" },
  bookingPrice: { fontSize: 14, color: "#C9A84C", fontWeight: "700" },
  bookingService: { fontSize: 12, color: "#C9A84C" },
  bookingDateTime: { fontSize: 12, color: "#9A9A9A" },
  customerPhone: { fontSize: 11, color: "#4A4A4A" },

  cancelBtn: {
    width: 36,
    height: 36,
    borderWidth: 1,
    borderColor: "#EF4444",
    borderRadius: 2,
    justifyContent: "center",
    alignItems: "center",
  },
  cancelBtnText: { fontSize: 14, color: "#EF4444", fontWeight: "700" },

  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.85)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  modalCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    padding: 24,
    width: "100%",
    gap: 16,
  },
  modalTitle: { fontSize: 14, fontWeight: "800", color: "#FFFFFF", letterSpacing: 3, textAlign: "center" },
  modalText: { fontSize: 13, color: "#9A9A9A", textAlign: "center", lineHeight: 20 },
  modalButtons: { flexDirection: "row", gap: 10 },
  modalCancelBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#2A2A2A",
    paddingVertical: 12,
    borderRadius: 2,
    alignItems: "center",
  },
  modalCancelText: { color: "#9A9A9A", fontSize: 12, fontWeight: "600", letterSpacing: 1 },
  modalConfirmBtn: {
    flex: 1,
    backgroundColor: "#EF4444",
    paddingVertical: 12,
    borderRadius: 2,
    alignItems: "center",
  },
  modalConfirmText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700", letterSpacing: 1 },
});
