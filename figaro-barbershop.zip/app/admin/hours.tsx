import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

type DayKey = "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday" | "sunday";

const DAY_LABELS: Record<DayKey, string> = {
  monday: "LUNEDÌ",
  tuesday: "MARTEDÌ",
  wednesday: "MERCOLEDÌ",
  thursday: "GIOVEDÌ",
  friday: "VENERDÌ",
  saturday: "SABATO",
  sunday: "DOMENICA",
};

const DAY_ORDER: DayKey[] = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

type DayConfig = {
  open: boolean;
  slots: { start: string; end: string }[];
};

type HoursConfig = Record<DayKey, DayConfig>;

const DEFAULT_CONFIG: HoursConfig = {
  monday: { open: false, slots: [] },
  tuesday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  wednesday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  thursday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  friday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  saturday: { open: true, slots: [{ start: "08:00", end: "20:00" }] },
  sunday: { open: false, slots: [] },
};

export default function AdminHoursScreen() {
  const router = useRouter();
  const { isAdminLoggedIn } = useBooking();
  const [config, setConfig] = useState<HoursConfig>(DEFAULT_CONFIG);
  const [saved, setSaved] = useState(false);

  const { data: hoursData, isLoading } = trpc.settings.getHours.useQuery();
  const updateMutation = trpc.settings.updateHours.useMutation({
    onSuccess: () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    },
  });

  useEffect(() => {
    if (hoursData) {
      setConfig(hoursData as HoursConfig);
    }
  }, [hoursData]);

  if (!isAdminLoggedIn) {
    router.replace("/admin/login" as never);
    return null;
  }

  const toggleDay = (day: DayKey) => {
    setConfig((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        open: !prev[day].open,
        slots: !prev[day].open && prev[day].slots.length === 0
          ? [{ start: "09:00", end: "18:00" }]
          : prev[day].slots,
      },
    }));
  };

  const updateSlot = (day: DayKey, index: number, field: "start" | "end", value: string) => {
    setConfig((prev) => {
      const newSlots = [...prev[day].slots];
      newSlots[index] = { ...newSlots[index], [field]: value };
      return { ...prev, [day]: { ...prev[day], slots: newSlots } };
    });
  };

  const addSlot = (day: DayKey) => {
    setConfig((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        slots: [...prev[day].slots, { start: "09:00", end: "13:00" }],
      },
    }));
  };

  const removeSlot = (day: DayKey, index: number) => {
    setConfig((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        slots: prev[day].slots.filter((_, i) => i !== index),
      },
    }));
  };

  const handleSave = () => {
    updateMutation.mutate({ hoursConfig: config });
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← DASHBOARD</Text>
        </TouchableOpacity>
        <Text style={styles.title}>ORARI DI APERTURA</Text>
        <Text style={styles.subtitle}>Configura i giorni e gli orari del barbershop</Text>
      </View>

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator color="#C9A84C" size="large" />
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {DAY_ORDER.map((day) => {
            const dayConfig = config[day];
            return (
              <View key={day} style={styles.dayCard}>
                {/* Day Header */}
                <View style={styles.dayHeader}>
                  <Text style={styles.dayLabel}>{DAY_LABELS[day]}</Text>
                  <View style={styles.switchRow}>
                    <Text style={[styles.switchLabel, dayConfig.open && styles.switchLabelOpen]}>
                      {dayConfig.open ? "APERTO" : "CHIUSO"}
                    </Text>
                    <Switch
                      value={dayConfig.open}
                      onValueChange={() => toggleDay(day)}
                      trackColor={{ false: "#2A2A2A", true: "#C9A84C" }}
                      thumbColor={dayConfig.open ? "#0A0A0A" : "#4A4A4A"}
                    />
                  </View>
                </View>

                {/* Slots */}
                {dayConfig.open && (
                  <View style={styles.slotsContainer}>
                    {dayConfig.slots.map((slot, index) => (
                      <View key={index} style={styles.slotRow}>
                        <Text style={styles.slotLabel}>Dalle</Text>
                        <TextInput
                          style={styles.timeInput}
                          value={slot.start}
                          onChangeText={(v) => updateSlot(day, index, "start", v)}
                          placeholder="08:30"
                          placeholderTextColor="#4A4A4A"
                          keyboardType="numbers-and-punctuation"
                          maxLength={5}
                        />
                        <Text style={styles.slotLabel}>alle</Text>
                        <TextInput
                          style={styles.timeInput}
                          value={slot.end}
                          onChangeText={(v) => updateSlot(day, index, "end", v)}
                          placeholder="13:00"
                          placeholderTextColor="#4A4A4A"
                          keyboardType="numbers-and-punctuation"
                          maxLength={5}
                        />
                        <TouchableOpacity
                          onPress={() => removeSlot(day, index)}
                          style={styles.removeSlotBtn}
                          activeOpacity={0.7}
                        >
                          <Text style={styles.removeSlotText}>✕</Text>
                        </TouchableOpacity>
                      </View>
                    ))}
                    <TouchableOpacity
                      style={styles.addSlotBtn}
                      onPress={() => addSlot(day)}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.addSlotText}>+ AGGIUNGI FASCIA ORARIA</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            );
          })}

          {/* Save Button */}
          <TouchableOpacity
            style={[styles.saveBtn, (updateMutation.isPending || saved) && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={updateMutation.isPending || saved}
            activeOpacity={0.85}
          >
            {updateMutation.isPending ? (
              <ActivityIndicator color="#0A0A0A" />
            ) : (
              <Text style={styles.saveBtnText}>{saved ? "✓ SALVATO" : "SALVA ORARI"}</Text>
            )}
          </TouchableOpacity>
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: { fontSize: 20, fontWeight: "700", color: "#FFFFFF", letterSpacing: 3, marginBottom: 4 },
  subtitle: { fontSize: 12, color: "#9A9A9A" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },

  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 24, paddingTop: 16, paddingBottom: 40, gap: 12 },

  dayCard: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    overflow: "hidden",
  },
  dayHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 14,
  },
  dayLabel: { fontSize: 12, fontWeight: "700", color: "#FFFFFF", letterSpacing: 2 },
  switchRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  switchLabel: { fontSize: 10, color: "#4A4A4A", fontWeight: "600", letterSpacing: 1 },
  switchLabelOpen: { color: "#C9A84C" },

  slotsContainer: {
    borderTopWidth: 1,
    borderTopColor: "#2A2A2A",
    padding: 12,
    gap: 10,
  },
  slotRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "#0A0A0A",
    padding: 10,
    borderRadius: 2,
  },
  slotLabel: { fontSize: 11, color: "#9A9A9A" },
  timeInput: {
    flex: 1,
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 14,
    color: "#FFFFFF",
    textAlign: "center",
    fontWeight: "600",
  },
  removeSlotBtn: {
    width: 28,
    height: 28,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#EF4444",
    borderRadius: 2,
  },
  removeSlotText: { fontSize: 12, color: "#EF4444", fontWeight: "700" },

  addSlotBtn: {
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderStyle: "dashed",
    paddingVertical: 10,
    borderRadius: 2,
    alignItems: "center",
  },
  addSlotText: { fontSize: 10, color: "#9A9A9A", fontWeight: "600", letterSpacing: 2 },

  saveBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
    marginTop: 8,
  },
  saveBtnDisabled: { opacity: 0.7 },
  saveBtnText: { color: "#0A0A0A", fontSize: 14, fontWeight: "800", letterSpacing: 3 },
});
