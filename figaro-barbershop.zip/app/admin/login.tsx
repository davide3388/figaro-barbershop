import { useState } from "react";
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useBooking } from "@/lib/booking-context";
import { trpc } from "@/lib/trpc";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663619095330/F5CEDPAP64kSyYnUY5joFT/figaro-logo-dHGfp8dqetyhv7udTJTNRF.png";

export default function AdminLoginScreen() {
  const router = useRouter();
  const { setAdminLoggedIn } = useBooking();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const loginMutation = trpc.admin.login.useMutation({
    onSuccess: () => {
      setAdminLoggedIn(true);
      router.replace("/admin/dashboard" as never);
    },
    onError: (err) => {
      setError(err.message || "Credenziali non valide");
    },
  });

  const handleLogin = () => {
    setError(null);
    if (!username.trim() || !password.trim()) {
      setError("Inserisci username e password");
      return;
    }
    loginMutation.mutate({ username: username.trim(), password: password.trim() });
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Back */}
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backText}>← TORNA ALLA HOME</Text>
          </TouchableOpacity>

          {/* Logo */}
          <View style={styles.logoContainer}>
            <Image source={{ uri: LOGO_URL }} style={styles.logo} resizeMode="contain" />
          </View>

          {/* Title */}
          <View style={styles.titleContainer}>
            <Text style={styles.title}>AREA ADMIN</Text>
            <View style={styles.divider} />
            <Text style={styles.subtitle}>Accesso riservato al personale</Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>USERNAME</Text>
              <TextInput
                style={[styles.input, error ? styles.inputError : null]}
                value={username}
                onChangeText={setUsername}
                placeholder="admin"
                placeholderTextColor="#4A4A4A"
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="next"
              />
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>PASSWORD</Text>
              <TextInput
                style={[styles.input, error ? styles.inputError : null]}
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                placeholderTextColor="#4A4A4A"
                secureTextEntry
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />
            </View>

            {error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}

            <TouchableOpacity
              style={[styles.loginBtn, loginMutation.isPending && styles.loginBtnDisabled]}
              onPress={handleLogin}
              disabled={loginMutation.isPending}
              activeOpacity={0.85}
            >
              {loginMutation.isPending ? (
                <ActivityIndicator color="#0A0A0A" />
              ) : (
                <Text style={styles.loginBtnText}>ACCEDI</Text>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 40,
    backgroundColor: "#0A0A0A",
  },
  backBtn: { marginBottom: 24 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },

  logoContainer: { alignItems: "center", marginBottom: 24 },
  logo: { width: 140, height: 140 },

  titleContainer: { alignItems: "center", marginBottom: 40 },
  title: { fontSize: 18, fontWeight: "800", color: "#FFFFFF", letterSpacing: 5 },
  divider: { width: 40, height: 1, backgroundColor: "#C9A84C", marginVertical: 12 },
  subtitle: { fontSize: 12, color: "#9A9A9A", letterSpacing: 1 },

  form: { gap: 20 },
  fieldGroup: { gap: 8 },
  label: { fontSize: 10, fontWeight: "700", color: "#C9A84C", letterSpacing: 3 },
  input: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: "#FFFFFF",
  },
  inputError: { borderColor: "#EF4444" },

  errorBox: {
    backgroundColor: "#1A0A0A",
    borderWidth: 1,
    borderColor: "#EF4444",
    borderRadius: 2,
    padding: 12,
  },
  errorText: { color: "#EF4444", fontSize: 13, textAlign: "center" },

  loginBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
    marginTop: 8,
  },
  loginBtnDisabled: { opacity: 0.6 },
  loginBtnText: { color: "#0A0A0A", fontSize: 14, fontWeight: "800", letterSpacing: 3 },
});
