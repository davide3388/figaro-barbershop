import { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { StepBar } from "@/components/step-bar";
import { useBooking } from "@/lib/booking-context";

export default function RegisterScreen() {
  const router = useRouter();
  const { setCustomer, savedPhone, booking } = useBooking();

  const [firstName, setFirstName] = useState(booking.customer?.firstName ?? "");
  const [lastName, setLastName] = useState(booking.customer?.lastName ?? "");
  const [phone, setPhone] = useState(booking.customer?.phone ?? savedPhone ?? "");
  const [errors, setErrors] = useState<{ firstName?: string; lastName?: string; phone?: string }>({});

  const validate = () => {
    const newErrors: typeof errors = {};
    if (!firstName.trim()) newErrors.firstName = "Nome obbligatorio";
    if (!lastName.trim()) newErrors.lastName = "Cognome obbligatorio";
    if (!phone.trim() || phone.trim().length < 6) newErrors.phone = "Telefono non valido";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleContinue = () => {
    if (!validate()) return;
    setCustomer({ firstName: firstName.trim(), lastName: lastName.trim(), phone: phone.trim() });
    router.push("/service-select");
  };

  return (
    <ScreenContainer containerClassName="bg-background" edges={["top", "left", "right"]}>
      <StepBar currentStep={1} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
              <Text style={styles.backText}>← INDIETRO</Text>
            </TouchableOpacity>
            <Text style={styles.title}>I TUOI DATI</Text>
            <Text style={styles.subtitle}>Inserisci le tue informazioni per procedere</Text>
          </View>

          {/* Form */}
          <View style={styles.form}>
            <View style={styles.fieldGroup}>
              <Text style={styles.label}>NOME</Text>
              <TextInput
                style={[styles.input, errors.firstName ? styles.inputError : null]}
                value={firstName}
                onChangeText={setFirstName}
                placeholder="Es. Marco"
                placeholderTextColor="#4A4A4A"
                autoCapitalize="words"
                returnKeyType="next"
              />
              {errors.firstName ? <Text style={styles.errorText}>{errors.firstName}</Text> : null}
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>COGNOME</Text>
              <TextInput
                style={[styles.input, errors.lastName ? styles.inputError : null]}
                value={lastName}
                onChangeText={setLastName}
                placeholder="Es. Rossi"
                placeholderTextColor="#4A4A4A"
                autoCapitalize="words"
                returnKeyType="next"
              />
              {errors.lastName ? <Text style={styles.errorText}>{errors.lastName}</Text> : null}
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>TELEFONO</Text>
              <TextInput
                style={[styles.input, errors.phone ? styles.inputError : null]}
                value={phone}
                onChangeText={setPhone}
                placeholder="Es. 3391234567"
                placeholderTextColor="#4A4A4A"
                keyboardType="phone-pad"
                returnKeyType="done"
                onSubmitEditing={handleContinue}
              />
              {errors.phone ? <Text style={styles.errorText}>{errors.phone}</Text> : null}
            </View>

            <TouchableOpacity style={styles.continueBtn} onPress={handleContinue} activeOpacity={0.85}>
              <Text style={styles.continueBtnText}>CONTINUA</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: "#0A0A0A" },
  scrollContent: { paddingBottom: 40 },

  header: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 32,
    borderBottomWidth: 1,
    borderBottomColor: "#2A2A2A",
  },
  backBtn: { marginBottom: 16 },
  backText: { fontSize: 11, color: "#C9A84C", letterSpacing: 2, fontWeight: "600" },
  title: {
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    letterSpacing: 3,
    marginBottom: 8,
  },
  subtitle: { fontSize: 13, color: "#9A9A9A" },

  form: {
    paddingHorizontal: 24,
    paddingTop: 32,
    gap: 20,
  },
  fieldGroup: { gap: 8 },
  label: {
    fontSize: 10,
    fontWeight: "700",
    color: "#C9A84C",
    letterSpacing: 3,
  },
  input: {
    backgroundColor: "#1A1A1A",
    borderWidth: 1,
    borderColor: "#2A2A2A",
    borderRadius: 2,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: "#FFFFFF",
  },
  inputError: { borderColor: "#EF4444" },
  errorText: { fontSize: 11, color: "#EF4444" },

  continueBtn: {
    backgroundColor: "#C9A84C",
    paddingVertical: 16,
    borderRadius: 2,
    alignItems: "center",
    marginTop: 12,
  },
  continueBtnText: {
    color: "#0A0A0A",
    fontSize: 14,
    fontWeight: "800",
    letterSpacing: 3,
  },
});
