# Figaro Barbershop — Design Plan

## Brand Identity
- **Nome**: Figaro Barbershop (Est. 2021)
- **Palette**: Sfondo `#0A0A0A` (nero), Oro `#C9A84C`, Testo bianco/crema, Superfici `#1A1A1A`
- **Tipografia**: Serif per titoli (Georgia/serif), Sans-serif per corpo
- **Stile**: Dark luxury, art deco, premium

---

## Screen List

### Flusso Cliente
1. **HomeScreen** — Hero con immagine barbershop, titolo serif grande, bottone oro CTA
2. **RegisterScreen** — Form registrazione cliente (nome, cognome, telefono)
3. **ServiceSelectScreen** — Lista dark con card bordate, sezioni BARBIERE / ESTETICA
4. **DateSelectScreen** — Card orizzontali scorrevoli per selezione data (solo giorni aperti)
5. **TimeSelectScreen** — Griglia slot orari dark (solo slot liberi)
6. **ConfirmScreen** — Riepilogo prenotazione stile receipt dark
7. **SuccessScreen** — Schermata conferma prenotazione
8. **BookingsListScreen** — Lista prenotazioni cliente con cancellazione

### Area Admin
9. **AdminLoginScreen** — Login admin (admin / figaro2021), dark theme
10. **AdminDashboardScreen** — Dashboard prenotazioni (oggi / settimana / tutte), dark theme
11. **AdminHoursScreen** — Gestione orari apertura per giorno, toggle aperto/chiuso

---

## Primary Content and Functionality

### HomeScreen
- Hero image barbershop (background)
- Logo Figaro con "Est. 2021"
- Titolo serif grande: "FIGARO BARBERSHOP"
- Sottotitolo elegante
- Bottone oro full-width: "PRENOTA ORA"
- Link discreto: "Le mie prenotazioni" e "Area Admin"

### RegisterScreen
- Form: Nome, Cognome, Telefono
- Validazione campi
- Bottone oro "CONTINUA"
- Salvataggio locale con AsyncStorage

### ServiceSelectScreen
- Barra step: 01·SERVIZIO → 02·DATA → 03·ORARIO → 04·CONFERMA
- Sezione "BARBIERE": Taglio Capelli (€18), Barba (€12), Taglio + Barba (€25)
- Sezione "ESTETICA": Sopracciglia (€10), Ceretta (€15), Trattamento Viso (€20)
- Card bordate oro su sfondo dark
- Durata servizio mostrata (es. 30 min)

### DateSelectScreen
- Barra step: 02·DATA attivo
- Card orizzontali scorrevoli: GIO 30 APR, VEN 1 MAG, SAB 2 MAG...
- Solo giorni aperti (da API server)
- Prossimi 14 giorni disponibili
- Card selezionata: bordo oro, sfondo leggermente illuminato

### TimeSelectScreen
- Barra step: 03·ORARIO attivo
- Griglia 3 colonne di slot orari
- Slot disponibili: bordo oro, testo bianco
- Slot occupati: grigi, non selezionabili
- Orari: Mar-Ven 08:30-13:00 / 15:30-20:00, Sab 08:00-20:00

### ConfirmScreen
- Barra step: 04·CONFERMA attivo
- Tabella riepilogo stile receipt dark:
  - Cliente, Servizio, Data, Orario, Prezzo
- Bottone oro "CONFERMA PRENOTAZIONE"
- Bottone secondario "MODIFICA"

### SuccessScreen
- Icona check oro animata
- "Prenotazione Confermata!"
- Riepilogo essenziale
- Bottone "TORNA ALLA HOME"

### BookingsListScreen
- Lista prenotazioni del cliente (da telefono salvato)
- Card per ogni prenotazione: servizio, data, orario
- Bottone cancellazione con Modal di conferma cross-platform
- Stato: Confermata / Cancellata

### AdminLoginScreen
- Logo Figaro
- Form: Username, Password
- Credenziali: admin / figaro2021
- Bottone oro "ACCEDI"

### AdminDashboardScreen
- Header con logo e bottone logout
- Filtri: OGGI / SETTIMANA / TUTTE
- Lista prenotazioni con: nome cliente, servizio, data, orario
- Bottone cancellazione con Modal di conferma
- Badge contatore prenotazioni

### AdminHoursScreen
- Lista giorni settimana (Lun-Dom)
- Toggle aperto/chiuso per ogni giorno
- Aggiunta/rimozione fasce orarie per giorno
- Salvataggio su database
- Orari default: Mar-Ven 08:30-13:00 / 15:30-20:00, Sab 08:00-20:00

---

## Key User Flows

### Flusso Prenotazione Cliente
1. Home → tap "PRENOTA ORA"
2. RegisterScreen → inserisce nome, cognome, telefono → "CONTINUA"
3. ServiceSelectScreen → seleziona servizio (es. Taglio Capelli €18)
4. DateSelectScreen → seleziona data disponibile
5. TimeSelectScreen → seleziona slot orario libero
6. ConfirmScreen → verifica riepilogo → "CONFERMA PRENOTAZIONE"
7. SuccessScreen → conferma avvenuta

### Flusso Cancellazione Cliente
1. Home → "Le mie prenotazioni"
2. BookingsListScreen → lista prenotazioni
3. Tap "Cancella" → Modal di conferma → conferma cancellazione

### Flusso Admin
1. Home → "Area Admin"
2. AdminLoginScreen → inserisce credenziali → accede
3. AdminDashboardScreen → visualizza prenotazioni
4. Cancella prenotazione → Modal di conferma
5. Gestione orari → AdminHoursScreen → modifica orari → salva

---

## Color Choices
- **Background principale**: `#0A0A0A`
- **Superficie card**: `#1A1A1A`
- **Superficie elevata**: `#242424`
- **Oro primario**: `#C9A84C`
- **Oro hover**: `#D4B85A`
- **Testo principale**: `#FFFFFF`
- **Testo secondario**: `#9A9A9A`
- **Bordo**: `#2A2A2A`
- **Bordo oro**: `#C9A84C`
- **Errore**: `#EF4444`
- **Successo**: `#22C55E`
