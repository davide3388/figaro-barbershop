# Figaro Barbershop — TODO

## Database & Backend
- [x] Schema DB: tabelle bookings, customers, business_settings
- [x] API: GET/POST/DELETE prenotazioni
- [x] API: GET/PUT impostazioni orari
- [x] Logica slot disponibili per tipo servizio (hair/beard/beauty separati)

## Schermate Cliente
- [x] Home screen con branding Figaro (Est. 2021)
- [x] Registrazione cliente (nome, cognome, telefono)
- [x] Selezione servizio con prezzi e categorie
- [x] Calendario selezione data con giorni apertura/chiusura
- [x] Griglia orari disponibili (solo slot liberi)
- [x] Conferma prenotazione con riepilogo
- [x] Schermata successo prenotazione
- [x] Lista prenotazioni cliente con cancellazione

## Area Admin
- [x] Login admin (admin / figaro2021)
- [x] Dashboard prenotazioni (oggi / settimana / tutte)
- [x] Cancellazione prenotazione con Modal cross-platform
- [x] Gestione orari apertura per giorno
- [x] Toggle aperto/chiuso per giorno
- [x] Aggiunta/rimozione fasce orarie
- [x] Salvataggio orari su database

## Branding & UI
- [x] Generazione logo Figaro (forbici + rasoio, stile art deco)
- [x] Configurazione tema colori (oro #C9A84C, nero, crema)
- [x] Aggiornamento app.config.ts con nome e logo
- [x] Orari corretti: Mar-Ven 08:30-13:00 / 15:30-20:00, Sab 08:00-20:00
- [x] Redesign UI Dark/Luxury
- [x] Tema globale: sfondo #0A0A0A, oro #C9A84C, testo bianco
- [x] Home: hero con logo, testo, bottone oro full-width
- [x] Servizi: lista dark con card bordate, sezioni BARBIERE/ESTETICA
- [x] Date: card orizzontali scorrevoli
- [x] Orari: griglia slot dark
- [x] Conferma: tabella riepilogo dark stile receipt
- [x] Barra navigazione step (01·SERVIZIO, 02·DATA, 03·ORARIO, 04·CONFERMA)

## Test & Deploy
- [x] Flusso prenotazione implementato end-to-end
- [x] Area admin implementata
- [x] Checkpoint finale
