import { z } from "zod";
import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import type { HoursConfig, DayKey } from "./db";

// ─── Helpers ────────────────────────────────────────────────────────────────

function generateTimeSlots(start: string, end: string, durationMinutes: number): string[] {
  const slots: string[] = [];
  const [startH, startM] = start.split(":").map(Number);
  const [endH, endM] = end.split(":").map(Number);
  let current = startH * 60 + startM;
  const endTotal = endH * 60 + endM;
  while (current + durationMinutes <= endTotal) {
    const h = Math.floor(current / 60).toString().padStart(2, "0");
    const m = (current % 60).toString().padStart(2, "0");
    slots.push(`${h}:${m}`);
    current += durationMinutes;
  }
  return slots;
}

function getDayKey(dateStr: string): DayKey {
  const days: DayKey[] = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  const d = new Date(dateStr + "T12:00:00");
  return days[d.getDay()];
}

// ─── Router ────────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Business Settings ───────────────────────────────────────────────────────
  settings: router({
    getHours: publicProcedure.query(async () => {
      const settings = await db.getBusinessSettings();
      return settings.hoursConfig as HoursConfig;
    }),

    updateHours: publicProcedure
      .input(z.object({
        hoursConfig: z.record(z.string(), z.object({
          open: z.boolean(),
          slots: z.array(z.object({ start: z.string(), end: z.string() })),
        })),
      }))
      .mutation(async ({ input }) => {
        await db.updateBusinessSettings(input.hoursConfig);
        return { success: true };
      }),
  }),

  // ─── Customers ───────────────────────────────────────────────────────────────
  customers: router({
    upsert: publicProcedure
      .input(z.object({
        firstName: z.string().min(1).max(100),
        lastName: z.string().min(1).max(100),
        phone: z.string().min(6).max(20),
      }))
      .mutation(async ({ input }) => {
        return db.upsertCustomer(input);
      }),

    getByPhone: publicProcedure
      .input(z.object({ phone: z.string() }))
      .query(async ({ input }) => {
        return db.getCustomerByPhone(input.phone);
      }),
  }),

  // ─── Bookings ────────────────────────────────────────────────────────────────
  bookings: router({
    create: publicProcedure
      .input(z.object({
        firstName: z.string().min(1).max(100),
        lastName: z.string().min(1).max(100),
        phone: z.string().min(6).max(20),
        serviceId: z.string(),
        serviceName: z.string(),
        servicePrice: z.number().int().positive(),
        serviceDuration: z.number().int().positive(),
        bookingDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        bookingTime: z.string().regex(/^\d{2}:\d{2}$/),
      }))
      .mutation(async ({ input }) => {
        const customer = await db.upsertCustomer({
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
        });
        if (!customer) throw new Error("Impossibile creare il cliente");
        const existingBookings = await db.getBookingsByDate(input.bookingDate);
        const isSlotTaken = existingBookings.some((b) => b.bookingTime === input.bookingTime);
        if (isSlotTaken) throw new Error("Slot non disponibile");
        const bookingId = await db.createBooking({
          customerId: customer.id,
          serviceId: input.serviceId,
          serviceName: input.serviceName,
          servicePrice: input.servicePrice,
          serviceDuration: input.serviceDuration,
          bookingDate: input.bookingDate,
          bookingTime: input.bookingTime,
        });
        return { success: true, bookingId };
      }),

    getByPhone: publicProcedure
      .input(z.object({ phone: z.string() }))
      .query(async ({ input }) => {
        return db.getBookingsByPhone(input.phone);
      }),

    getByDate: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        return db.getBookingsByDate(input.date);
      }),

    getByDateRange: publicProcedure
      .input(z.object({ startDate: z.string(), endDate: z.string() }))
      .query(async ({ input }) => {
        return db.getBookingsByDateRange(input.startDate, input.endDate);
      }),

    getAll: publicProcedure.query(async () => {
      return db.getAllBookings();
    }),

    cancel: publicProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input }) => {
        await db.cancelBooking(input.id);
        return { success: true };
      }),

    getAvailableSlots: publicProcedure
      .input(z.object({
        date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        duration: z.number().int().positive().default(30),
      }))
      .query(async ({ input }) => {
        const settings = await db.getBusinessSettings();
        const hoursConfig = settings.hoursConfig as HoursConfig;
        const dayKey = getDayKey(input.date);
        const dayConfig = hoursConfig[dayKey];
        if (!dayConfig || !dayConfig.open) return { available: [], isOpen: false };
        const allSlots: string[] = [];
        for (const slot of dayConfig.slots) {
          allSlots.push(...generateTimeSlots(slot.start, slot.end, input.duration));
        }
        const existingBookings = await db.getBookingsByDate(input.date);
        const bookedTimes = new Set(existingBookings.map((b) => b.bookingTime));
        const available = allSlots.filter((s) => !bookedTimes.has(s));
        return { available, isOpen: true };
      }),

    getOpenDays: publicProcedure
      .input(z.object({ startDate: z.string(), endDate: z.string() }))
      .query(async ({ input }) => {
        const settings = await db.getBusinessSettings();
        const hoursConfig = settings.hoursConfig as HoursConfig;
        const days: DayKey[] = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
        const openDays: string[] = [];
        const start = new Date(input.startDate + "T12:00:00");
        const end = new Date(input.endDate + "T12:00:00");
        const current = new Date(start);
        while (current <= end) {
          const dayKey = days[current.getDay()];
          if (hoursConfig[dayKey]?.open) {
            const y = current.getFullYear();
            const m = (current.getMonth() + 1).toString().padStart(2, "0");
            const d = current.getDate().toString().padStart(2, "0");
            openDays.push(`${y}-${m}-${d}`);
          }
          current.setDate(current.getDate() + 1);
        }
        return openDays;
      }),
  }),

  // ─── Admin ───────────────────────────────────────────────────────────────────
  admin: router({
    login: publicProcedure
      .input(z.object({ username: z.string(), password: z.string() }))
      .mutation(({ input }) => {
        if (input.username === "admin" && input.password === "figaro2021") {
          return { success: true, token: "figaro-admin-token-2021" };
        }
        throw new Error("Credenziali non valide");
      }),
  }),
});

export type AppRouter = typeof appRouter;
