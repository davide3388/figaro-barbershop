import { and, eq, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  bookings,
  businessSettings,
  customers,
  InsertBooking,
  InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ─── Customers ───────────────────────────────────────────────────────────────

export async function upsertCustomer(data: { firstName: string; lastName: string; phone: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(customers).values(data).onDuplicateKeyUpdate({
    set: { firstName: data.firstName, lastName: data.lastName },
  });
  const result = await db.select().from(customers).where(eq(customers.phone, data.phone)).limit(1);
  return result[0];
}

export async function getCustomerByPhone(phone: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Bookings ────────────────────────────────────────────────────────────────

export async function createBooking(data: InsertBooking) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(bookings).values(data);
  return result[0].insertId;
}

export async function getBookingsByDate(date: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookings).where(
    and(eq(bookings.bookingDate, date), eq(bookings.status, "confirmed"))
  );
}

export async function getBookingsByDateRange(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: bookings.id,
    customerId: bookings.customerId,
    serviceId: bookings.serviceId,
    serviceName: bookings.serviceName,
    servicePrice: bookings.servicePrice,
    serviceDuration: bookings.serviceDuration,
    bookingDate: bookings.bookingDate,
    bookingTime: bookings.bookingTime,
    status: bookings.status,
    createdAt: bookings.createdAt,
    customerFirstName: customers.firstName,
    customerLastName: customers.lastName,
    customerPhone: customers.phone,
  }).from(bookings)
    .leftJoin(customers, eq(bookings.customerId, customers.id))
    .where(
      and(
        gte(bookings.bookingDate, startDate),
        lte(bookings.bookingDate, endDate),
        eq(bookings.status, "confirmed")
      )
    );
}

export async function getAllBookings() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: bookings.id,
    customerId: bookings.customerId,
    serviceId: bookings.serviceId,
    serviceName: bookings.serviceName,
    servicePrice: bookings.servicePrice,
    serviceDuration: bookings.serviceDuration,
    bookingDate: bookings.bookingDate,
    bookingTime: bookings.bookingTime,
    status: bookings.status,
    createdAt: bookings.createdAt,
    customerFirstName: customers.firstName,
    customerLastName: customers.lastName,
    customerPhone: customers.phone,
  }).from(bookings)
    .leftJoin(customers, eq(bookings.customerId, customers.id))
    .where(eq(bookings.status, "confirmed"));
}

export async function getBookingsByPhone(phone: string) {
  const db = await getDb();
  if (!db) return [];
  const customer = await getCustomerByPhone(phone);
  if (!customer) return [];
  return db.select().from(bookings).where(eq(bookings.customerId, customer.id));
}

export async function cancelBooking(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(bookings).set({ status: "cancelled" }).where(eq(bookings.id, id));
}

// ─── Business Settings ───────────────────────────────────────────────────────

const DEFAULT_HOURS_CONFIG = {
  monday: { open: false, slots: [] as { start: string; end: string }[] },
  tuesday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  wednesday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  thursday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  friday: { open: true, slots: [{ start: "08:30", end: "13:00" }, { start: "15:30", end: "20:00" }] },
  saturday: { open: true, slots: [{ start: "08:00", end: "20:00" }] },
  sunday: { open: false, slots: [] as { start: string; end: string }[] },
};

// Orari corretti per Figaro Barbershop:
// Martedì-Venerdì: 08:30-13:00 e 15:30-20:00
// Sabato: 08:00-20:00 (no stop)
// Lunedì e Domenica: chiuso

export type HoursConfig = typeof DEFAULT_HOURS_CONFIG;
export type DayKey = keyof HoursConfig;

export async function getBusinessSettings() {
  const db = await getDb();
  if (!db) return { id: 0, hoursConfig: DEFAULT_HOURS_CONFIG as unknown, updatedAt: new Date() };
  const result = await db.select().from(businessSettings).limit(1);
  if (result.length === 0) {
    await db.insert(businessSettings).values({ hoursConfig: DEFAULT_HOURS_CONFIG });
    const created = await db.select().from(businessSettings).limit(1);
    return created[0];
  }
  return result[0];
}

export async function updateBusinessSettings(hoursConfig: unknown) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await db.select().from(businessSettings).limit(1);
  if (existing.length === 0) {
    await db.insert(businessSettings).values({ hoursConfig });
  } else {
    await db.update(businessSettings).set({ hoursConfig }).where(eq(businessSettings.id, existing[0].id));
  }
}
