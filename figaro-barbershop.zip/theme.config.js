/** @type {const} */
const themeColors = {
  primary: { light: '#C9A84C', dark: '#C9A84C' },
  background: { light: '#0A0A0A', dark: '#0A0A0A' },
  surface: { light: '#1A1A1A', dark: '#1A1A1A' },
  foreground: { light: '#FFFFFF', dark: '#FFFFFF' },
  muted: { light: '#9A9A9A', dark: '#9A9A9A' },
  border: { light: '#2A2A2A', dark: '#2A2A2A' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  gold: { light: '#C9A84C', dark: '#C9A84C' },
  cream: { light: '#F5F0E8', dark: '#F5F0E8' },
};

module.exports = { themeColors };
