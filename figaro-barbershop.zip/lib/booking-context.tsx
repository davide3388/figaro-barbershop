import React, { createContext, useContext, useState, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface Service {
  id: string;
  name: string;
  price: number; // in centesimi
  duration: number; // in minuti
  category: "barbiere" | "estetica";
  description: string;
}

export interface CustomerInfo {
  firstName: string;
  lastName: string;
  phone: string;
}

export interface BookingState {
  customer: CustomerInfo | null;
  service: Service | null;
  date: string | null; // "YYYY-MM-DD"
  time: string | null; // "HH:MM"
}

interface BookingContextType {
  booking: BookingState;
  setCustomer: (customer: CustomerInfo) => void;
  setService: (service: Service) => void;
  setDate: (date: string) => void;
  setTime: (time: string) => void;
  resetBooking: () => void;
  savedPhone: string | null;
  setSavedPhone: (phone: string) => void;
  isAdminLoggedIn: boolean;
  setAdminLoggedIn: (v: boolean) => void;
}

const BookingContext = createContext<BookingContextType | null>(null);

const PHONE_KEY = "figaro_saved_phone";
const ADMIN_KEY = "figaro_admin_logged_in";

export function BookingProvider({ children }: { children: ReactNode }) {
  const [booking, setBooking] = useState<BookingState>({
    customer: null,
    service: null,
    date: null,
    time: null,
  });
  const [savedPhone, setSavedPhoneState] = useState<string | null>(null);
  const [isAdminLoggedIn, setAdminLoggedInState] = useState(false);

  React.useEffect(() => {
    AsyncStorage.getItem(PHONE_KEY).then((phone) => {
      if (phone) setSavedPhoneState(phone);
    });
    AsyncStorage.getItem(ADMIN_KEY).then((val) => {
      if (val === "true") setAdminLoggedInState(true);
    });
  }, []);

  const setCustomer = (customer: CustomerInfo) => {
    setBooking((prev) => ({ ...prev, customer }));
    AsyncStorage.setItem(PHONE_KEY, customer.phone);
    setSavedPhoneState(customer.phone);
  };

  const setService = (service: Service) => {
    setBooking((prev) => ({ ...prev, service, date: null, time: null }));
  };

  const setDate = (date: string) => {
    setBooking((prev) => ({ ...prev, date, time: null }));
  };

  const setTime = (time: string) => {
    setBooking((prev) => ({ ...prev, time }));
  };

  const resetBooking = () => {
    setBooking({ customer: null, service: null, date: null, time: null });
  };

  const setSavedPhone = (phone: string) => {
    setSavedPhoneState(phone);
    AsyncStorage.setItem(PHONE_KEY, phone);
  };

  const setAdminLoggedIn = (v: boolean) => {
    setAdminLoggedInState(v);
    AsyncStorage.setItem(ADMIN_KEY, v ? "true" : "false");
  };

  return (
    <BookingContext.Provider
      value={{
        booking,
        setCustomer,
        setService,
        setDate,
        setTime,
        resetBooking,
        savedPhone,
        setSavedPhone,
        isAdminLoggedIn,
        setAdminLoggedIn,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error("useBooking must be used within BookingProvider");
  return ctx;
}

export const SERVICES: Service[] = [
  { id: "beard", name: "Barba", price: 500, duration: 15, category: "barbiere", description: "Rasatura e rifinitura barba" },
  { id: "haircut", name: "Taglio Capelli", price: 1000, duration: 30, category: "barbiere", description: "Taglio classico o moderno" },
  { id: "haircut_shampoo", name: "Taglio + Shampoo", price: 1500, duration: 45, category: "barbiere", description: "Taglio con shampoo e styling" },
  { id: "complete_service", name: "Servizio Completo", price: 2000, duration: 60, category: "barbiere", description: "Taglio, barba, shampoo e styling" },
  { id: "eyebrows", name: "Sopracciglia", price: 500, duration: 15, category: "estetica", description: "Definizione e pulizia" },
  { id: "face_cleaning", name: "Pulizia del Viso", price: 2000, duration: 40, category: "estetica", description: "Pulizia profonda e trattamento" },
  { id: "manicure", name: "Manicure", price: 1000, duration: 30, category: "estetica", description: "Manicure classica o gel" },
];
